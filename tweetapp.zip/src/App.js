import { useEffect, useState } from 'react';
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../node_modules/bootstrap-icons/font/bootstrap-icons.css'
import LoginComponent from './components/login/LoginComponent';
import NavBarComponent from './components/navbar/NavBarComponent';
import SignUpComponent from './components/register/SignUpComponent';
import ResetPassword from './components/login/ResetPassword';
import ForgotPassword from './components/login/ForgotPassword';
import DashBoardComponent from './components/dashboard/DashBoardComponent';
import PostTweet from './components/dashboard/PostTweet';
import ShowMyTweets from './components/dashboard/ShowMyTweets';
import UserDetails from './components/user/UserDetails';
import UserProfile from './components/user/UserProfile';

function App() {

  const [username, setUsername] = useState('');

  useEffect(() => {
    const interval = setInterval(() => {
      setUsername(localStorage.getItem('authenticatedUser'))
    }, 500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="App">
      <Router>
        <NavBarComponent loggedInUser={username} />
        <Switch>
          <Route exact path="/login">
            <LoginComponent />
          </Route>
          <Route exact path='/reset'>
            <ResetPassword />
          </Route>
          <Route exact path="/register">
            <SignUpComponent />
          </Route>
          <Route exact path="/home">
            <DashBoardComponent />
          </Route>
          <Route exact path="/forgot">
            <ForgotPassword />
          </Route>
          <Route exact path='/users'>
            <div className="container" style={{ marginTop: "100px" }}>
              <div className="row justify-content-center">
                <UserDetails />
              </div>
            </div>
          </Route>
          <Route exact path="/:user/post">
            <PostTweet />
          </Route>
          <Route exact path='/myTweets'>
            <div className="container" style={{ marginTop: "100px" }}>
              <ShowMyTweets />
            </div>
          </Route> 
          <Route exact path='/profile'>            
              <UserProfile />            
          </Route>          
        </Switch>
      </Router>
    </div>
  );
}

export default App;
