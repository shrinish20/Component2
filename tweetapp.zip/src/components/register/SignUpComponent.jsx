import React, { useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Redirect } from 'react-router-dom';
import Modal from '../../responsemessage/Modal';
import UserService from '../../services/UserService';

const SignUpComponent = () => {
    const [showMsg, setShowMsg] = useState(false);
    const [status, setStatus] = useState('');
    const [statusMsg, setStatusMsg] = useState('');
    const { register, handleSubmit, formState: { errors }, watch } = useForm({});
    const password = useRef({});
    password.current = watch("password", "");


    const formSubmit = (values) => {
        const data = {
            firstName: values.firstname,
            lastName: values.lasstname,
            emailId: values.email,
            loginId: values.username,
            userPassword: values.password,
            contactNumber: values.contact
        };

        UserService.registerUser(data).then(response => {
            setShowMsg(true);
            if (response.data.statusMessage === 'Registration Successful' && response.status === 201) {
                setStatus("Success");                
                setStatusMsg(response.data.statusMessage);
            }

        }).catch(err => {
            setStatus("Failed");
            setStatusMsg("Registration UnSuccessful. Please try again later");
        });
    }

    const validatePassword = (value) => {
        if (value.length < 8) {
            return 'Password should be atleast 8 characters.';
        } else if (!/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s)(?=.*[!@#$*])/.test(value)) {
            return 'Password should contain atleast one uppercase letter, lowercase letter, digit and special characters.';
        }
        return true;
    }

    return (
        <>
            {status === "Success" ? <Redirect to="/login"/> : null}
            <Modal show={showMsg} title={status} message={statusMsg} onClose={() => setShowMsg(false)} />
            <div className="auth-wrapper pb-3">
                <div className="main-signup-container">
                    <form onSubmit={e => e.preventDefault()}>
                        <div className="form-header">
                            <h4>Register</h4>
                        </div>
                        <div className="row justify-content-between">
                            <div className="form-group col-6 form-alignment">
                                <label>First name <small>
                                    <span className="text-danger"> *</span></small>
                                </label>
                                <input type="text" id="fname" className="form-control" name="firstname" placeholder="Enter firstname"
                                    {...register('firstname', {
                                        required: 'Firstname is required',
                                    })} />
                                {errors.firstname && (<span className="errorMsg">{errors.firstname.message}</span>)}
                            </div>
                            <div className="form-group col-6 form-alignment">
                                <label>Last name
                            <span className="text-danger"> *</span>
                                </label>
                                <input type="text" id="lname" name="lastname" className="form-control" placeholder="Enter lastname"
                                    {...register('lastname', {
                                        required: 'Lastname is required',
                                    })} />
                                {errors.lastname && (<span className="errorMsg">{errors.lastname.message}</span>)}
                            </div>

                        </div>
                        <div className="row justify-content-between">
                            <div className="form-group col-6 form-alignment">
                                <label>Email Address
                        <span className="text-danger">*</span></label>
                                <input type="text" id="email" name="email" className="form-control" placeholder="Enter email"
                                    {...register('email', {
                                        required: 'Email Address is required',
                                        pattern: {
                                            value: /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/,
                                            message: 'Email Address is not valid.'
                                        }
                                    })} />
                                {errors.email && (<span className="errorMsg">{errors.email.message}</span>)}
                            </div>
                            <div className="form-group col-6 form-alignment">
                                <label>Username
                        <span className="text-danger">*</span></label>
                                <input type="text" id="username" name="username" className="form-control" placeholder="Enter username"
                                    {...register('username', {
                                        required: 'Username is required',
                                        pattern: {
                                            value: /^[a-z0-9_@-]{5,15}$/,
                                            message: 'Username is not valid.'
                                        }
                                    })} />
                                {errors.email && (<span className="errorMsg">{errors.email.message}</span>)}
                            </div>
                        </div>
                        <div className="row justify-content-between">
                            <div className="form-group col-6 form-alignment">
                                <label>Phone number
                        <span className="text-danger"> *</span></label>
                                <input type="text" id="mob" className="form-control" name="contact" placeholder="Enter mobile number"
                                    {...register('contact', {
                                        required: 'Contact Number is required'
                                    })} />
                                {errors.contact && (<span className="errorMsg">{errors.contact.message}</span>)}
                            </div>
                            <div className="form-group col-6 form-alignment">
                                <label>Password
                        <span className="text-danger"> *</span></label>
                                <input type="password" id="cpassword" className="form-control" name="password" placeholder="Enter password"
                                    {...register('password', {
                                        required: 'You must specify a password',
                                        validate: validatePassword
                                    })} />
                                {errors.password && (<span className="errorMsg">{errors.password.message}</span>)}
                            </div>
                        </div>
                        <div className="row justify-content-between">
                            <div className="form-group col-6 form-alignment">
                                <label>Confirm Password
                        <span className="text-danger"> *</span></label>
                                <input type="password" id="password" className="form-control" name="confirmpassword" placeholder="Confirm Password"
                                    {...register('confirmpassword', {
                                        validate: value => value === password.current || "Password Mismatch."
                                    })} />
                                {errors.confirmpassword && (<span className="errorMsg">{errors.confirmpassword.message}</span>)}
                            </div>
                        </div>
                        <div style={{ padding: "5px 0px 0px 0px" }}>
                            {/* <button type="submit" className="btn btn-primary btn-block">Register Me</button> */}
                            <button type="submit" className="btn btn-primary" style={{ backgroundColor: "#1DA1F2", borderStyle: "none" }} onClick={handleSubmit(formSubmit)} > <i className="bi bi-twitter" style={{ paddingRight: "0.29rem" }}></i>Register Me</button>
                        </div>
                    </form>
                </div>
            </div>
        </>
    );
}

export default SignUpComponent;
