import React, { useEffect, useState } from 'react';
import Modal from '../../responsemessage/Modal';
import TweetService from '../../services/TweetService';
import ShowReplies from './ShowReplies';
import $ from 'jquery';
import avatar from '../../img/avatar.png';
import ReactTimeAgo from 'react-time-ago';

const ShowMyTweets = () => {

    const username = localStorage.getItem('authenticatedUser');
    const [myTweets, setmyTweets] = useState([]);
    const [isLiked, setIsLiked] = useState(false);
    const [isHide, setIsHide] = useState(false);
    const [updatedData, setupdatedData] = useState("");
    const [isShowReplyBox, setIsShowReplyBox] = useState(false);
    const [showMsg, setShowMsg] = useState(false);
    const [status, setStatus] = useState('');
    const [statusMsg, setStatusMsg] = useState('');

    useEffect(() => {
        getTweets();
    }, []);

    const getTweets = () => {
        TweetService.getTweets(username).then(response => {
            if (response.data.statusMessage === 'Successfully Retrieved' && response.status === 200) {
                setmyTweets(response.data.message);
            }
            console.log(response);
        }).catch(err => {
            if (err.response.data.statusMessage === 'No Tweets Found') {
                setShowMsg(true);
                setStatus("Failed");
                setStatusMsg(err.response.data.statusMessage);
                <Modal show={showMsg} title={status} message={statusMsg} onClose={() => setShowMsg(false)} />
            }
            console.log(err);
        });
    }
    const handleLike = (id) => {
        $('.tweet-content').each(function (x) {
            console.log(this.id);
            if (this.id !== id) {
                setIsLiked(!isLiked);
                TweetService.likeTweet(username, id, isLiked).then(response => {
                    console.log(response);
                }).catch(err => {
                    console.log(err);
                });
            }
        })
    }

    const toggleComments = (id) => {
        setIsHide(!isHide);
        $('.tweet-content').each(function (x) {
            console.log(this.id);
            if (this.id !== id) {
                $('#tweet-reply' + this.id).hide();
            }
        })
        $('#tweet-reply' + id).show()
    }

    const toggleReplyBox = (id) => {
        setIsShowReplyBox(!isShowReplyBox);
        $('.tweet-content').each(function (x) {
            if (this.id !== id) {
                $('#tweet-reply-box' + this.id).hide();
            }
        })
        $('#tweet-reply-box' + id).show()
    }

    const deleteTweet = (id) => {
        $('.tweet-content').each(function (x) {
            if (this.id === id) {
                TweetService.deleteTweet(username, id).then(response => {
                    window.location.reload(true);
                    console.log(response);
                }).catch(err => {
                    console.log(err);
                });
            }
        })
    }



    const updateTweet = (id) => {
        $('.tweet-content').each(function (x) {
            if (this.id === id) {
                const updateData = {
                    tweetMessage: updatedData
                }
                TweetService.updateTweet(username, id, updateData).then(response => {
                    window.location.reload(true);
                    console.log(response);
                }).catch(err => {
                    console.log(err);
                });
            }
        })
    }

    return (
        myTweets.map(tweetObj => (
            <div className="tweet-content row align-items-center justify-content-center" id={tweetObj.id} key={tweetObj.id} style={{ margin: "0px 15px 0px 15px", transition: "0.6s" }}>
                <div className="border p-3 mb-2 collapsible" style={{ borderRadius: "8px", display: "block!important", background: "#ffffff", boxShadow: "20px 10px 10px rgba(34, 35, 58, 0.2)", margin: "0px 5px" }}>
                    <img src={avatar} alt="User" className="flex-shrink-0 me-2 rounded-circle" style={{ width: 40, height: 40, display: "inline-block", verticalAlign: "top" }} />
                    <div style={{ textAlign: "left", display: "inline-block", wordWrap: "break-word", paddingTop: "5px" }}>
                        <h5 className="mb-auto" style={{ fontSize: "15px" }}>@{tweetObj.loginId}<sup><i className="bi bi-patch-check-fill" style={{ fontSize: "small", color: "#1DA1F2", paddingLeft: "5px" }}></i></sup>
                        <span className="fw-normal" style={{ fontSize: "10px", color: "black" }}> . <ReactTimeAgo date={tweetObj.postedDate} locale="en-US" timeStyle="twitter" />
                        </span>
                        </h5>

                        <p className="tweet">{tweetObj.tweetMessage}</p>
                        <ul className="list-inline float-right">
                            <li className="list-inline-item">
                                <button type="submit" className="btn btn-primary btn-sm" style={{ backgroundColor: "#1DA1F2", borderStyle: "none" }} onClick={() => handleLike(tweetObj.id)}>
                                    <i className={isLiked ? "bi bi-hand-thumbs-up-fill" : "bi bi-hand-thumbs-down-fill"} style={{ paddingRight: "0.29rem" }} />
                                    {tweetObj.likes}
                                </button>
                            </li>
                            <li className="list-inline-item">
                                <button type="button" className="btn btn-primary btn-sm toggle" style={{ backgroundColor: "#1DA1F2", borderStyle: "none" }} onClick={() => toggleComments(tweetObj.id)}>
                                    <i className="bi bi-chat-fill" />
                                </button>
                            </li>
                            <li className="list-inline-item">
                                <button type="button" className="btn btn-primary btn-sm toggle" style={{ backgroundColor: "#1DA1F2", borderStyle: "none" }} onClick={() => deleteTweet(tweetObj.id)}>
                                    <i className="bi bi-trash-fill" />
                                </button>
                            </li>
                            <li className="list-inline-item">
                                <button type="button" className="btn btn-primary btn-sm toggle" style={{ backgroundColor: "#1DA1F2", borderStyle: "none" }} onClick={() => toggleReplyBox(tweetObj.id)}>
                                    <i className="bi bi-pen-fill" />
                                </button>
                            </li>

                        </ul>
                    </div>
                    <div id={"tweet-reply" + tweetObj.id}>
                        {isHide && (<><hr className="mb-3" /><div><ShowReplies reply={tweetObj.reply} /></div></>)}
                    </div>
                    <div id={"tweet-reply-box" + tweetObj.id}>
                        {isShowReplyBox && <><hr />
                            <div className="form-group mb-2" style={{ margin: "0px 30px 0px 30px" }}>
                                <textarea className="form-control" name="update" placeholder={tweetObj.tweetMessage} rows={2} maxLength={144} value={updatedData} onChange={(event) => setupdatedData(event.target.value)} style={{ fontSize: "13px", resize: 'none' }} />
                            </div>
                            <button type="submit" className="btn btn-primary" style={{ float: "right", backgroundColor: "#1DA1F2", borderStyle: "none", marginRight: "30px" }} onClick={() => updateTweet(tweetObj.id)}><i className="bi bi-pencil-square"></i></button>
                        </>}
                    </div>
                </div>
            </div>
        ))
    );
}

export default ShowMyTweets;
