import React from 'react';

function ShowReplies(props) {
    const { reply } = props;
    return (
        reply.map(replyObj => (<>
            <div className="d-flex ml-0 comments-content" key={replyObj.id}>
                <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="other" className="flex-shrink-0 me-2 rounded-circle" style={{ width: 40, height: 40 }} />
                <div style={{ textAlign: "left" }}>
                    <h5 className="mb-auto" style={{ fontSize: "12px", fontWeight: "650" }}>@{replyObj.loginId}<sup><i class="bi bi-patch-check-fill" style={{ fontSize: "small", color: "#1DA1F2",  paddingLeft:"5px"}}></i></sup></h5>
                    <span className="fw-normal" style={{ fontSize: "11px", color: "#1DA1F2" }}>Posted on {replyObj.postedDate}</span>
                    <p className="comments-tweet mb-0">{replyObj.reply}</p>
                </div>
            </div>
            <hr/>
        </>))
    );
}

export default ShowReplies;