import { useState } from 'react';
import { useHistory } from 'react-router';
import TweetService from '../../services/TweetService';

const username = localStorage.getItem('authenticatedUser');
const PostTweet = () => {
    const history = useHistory();
    const [tweet, setTweet] = useState("");
    const tweetCount = 144;
    const [remCount, setRemCount] = useState(144);
    const handleChar = (event) => {
        const tweetLength = event.target.value.length;
        const currentLength = tweetCount - tweetLength;
        setRemCount(currentLength);
    }

    const postTweet = (event) => {
        event.preventDefault();
        const tweetData = {
            loginId: username,
            tweetMessage: tweet
        }
        TweetService.postTweet(tweetData).then(response => {
            history.push("/home");
        }).catch(err => {
            console.log(err);
        });
    }
    return (
        <div className="tweet-container">
            <div className="col-12">
                <div className="tweet">
                    <div className="tweet-heading pb-1">
                        <h4 style={{ textAlign: "left", color: "#1DA1F2" }}>Tweet Feed</h4>
                    </div>
                    <div className="tweet-body">
                        <div className="form-group">
                            <textarea className="form-control" name="tweet" maxLength={144} value={tweet} onChange={(event) => { handleChar(event); setTweet(event.target.value); }} placeholder="Enter here for tweet..." rows={4} />
                        </div>
                        <div style={{ padding: "14px 0px 0px 0px" }}>
                            <span style={{ float: "left", fontSize: "smaller", fontWeight: "bolder", color: "#1DA1F2" }}>Remaining characters {remCount}</span>
                            <button type="submit" className="btn btn-primary" style={{ marginTop: "6px", float: "right", backgroundColor: "#1DA1F2", borderStyle: "none" }} onClick={postTweet}><i className="bi bi-twitter" style={{ paddingRight: "0.29rem" }}></i>Post Tweet</button>
                        </div>
                        <div className="clearfix" />
                    </div>
                </div>
            </div>
        </div>
    );
}
export default PostTweet;
