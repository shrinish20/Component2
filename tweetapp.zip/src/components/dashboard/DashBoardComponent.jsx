import React, { useEffect, useState } from 'react';
import TweetService from '../../services/TweetService';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Modal from '../../responsemessage/Modal';
import ShowTweets from './ShowTweets';

const DashboardComponent = () => {
  const [allTweets, setAllTweets] = useState([]);
  const [showMsg, setShowMsg] = useState(false);
  const [status, setStatus] = useState('');
  const [statusMsg, setStatusMsg] = useState('');

  useEffect(() => {
    getAllTweets();
  }, []);

  const getAllTweets = () => {
    TweetService.getAllTweets().then(response => {
      if (response.data.statusMessage === 'Successfully Retrieved' && response.status === 200) {
        setAllTweets(response.data.message);
      }
      console.log(response);
    }).catch(err => {
      if (err.response.data.statusMessage === 'No Tweets Found') {
        setShowMsg(true);
        setStatus("Failed");
        setStatusMsg(err.response.data.statusMessage);
      }
      console.log(err);
    });
  }

  return (
    <>
      <Modal show={showMsg} title={status} message={statusMsg} onClose={() => setShowMsg(false)} />
      <div className="container" style={{marginTop: "100px"}}>
        <ShowTweets tweetList={allTweets} fromNavbar={false} />
      </div>
    </>);
}

export default DashboardComponent;