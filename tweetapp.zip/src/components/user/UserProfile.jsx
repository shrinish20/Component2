import React from 'react';
import avatar from '../../img/avatar.png';

const UserProfile = () => {
    return (
        <div className="container">
            <div className="row justify-content-center mx-2" style={{ marginTop: "100px", backgroundColor: "#ffffff", borderRadius: "8px" }}>
                <div className="col-md-3 border-right text-center">
                    <div className="d-flex flex-column align-items-center p-3 py-5">
                        <img src={avatar} alt="User" className="rounded-circle" style={{ width: 90, height: 90, display: "inline-block", verticalAlign: "top" }} />
                        <div className="pt-2">
                            <h6>Shriram Nishanth</h6>
                            <p className="mb-1" style={{ fontSize: "13px", color: "#1DA1F2", fontWeight: "bolder" }}>DeadShot20<span> | </span><span style={{ color: "black" }}>shrinis20@gmail.com</span></p>
                            <address>
                                <p className="mb-1" style={{ fontSize: "13px", color: "black" }}><b style={{ color: "black" }}>Contact No : </b>9962315447</p>
                            </address>
                        </div>
                    </div>
                </div>
                <div className="col-md-8">
                    <div className="p-3 py-5">
                        <div className="row mt-2">
                            <div className="col-md-5">
                                <input type="text" className="form-control" placeholder="First name" readOnly/>
                            </div>
                            <div className="col-md-5">
                                <input type="text" className="form-control" placeholder="Last name" readOnly/>
                            </div>
                        </div>
                        <div className="row mt-3">
                            <div className="col-md-5">
                                <input type="text" className="form-control" placeholder="Username" readOnly/>
                            </div>
                            <div className="col-md-5">
                                <input type="text" className="form-control" placeholder="Email Address" readOnly/>
                            </div>
                        </div>
                        <div className="row mt-3">
                            <div className="col-md-5">
                                <input type="text" className="form-control" placeholder="Contact Number" readOnly/>
                            </div>
                            <div className="col-md-5">
                                <input type="text" className="form-control" placeholder="Password" readOnly/>
                            </div>
                        </div>
                        <div className="mt-3 text-right pr-1">
                            <button type="submit" className="btn btn-primary" style={{ marginTop: "6px", float: "right", backgroundColor: "#1DA1F2", borderStyle: "none" }}><i className="bi bi-twitter" style={{ paddingRight: "0.29rem" }}></i>Post Tweet</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default UserProfile;
