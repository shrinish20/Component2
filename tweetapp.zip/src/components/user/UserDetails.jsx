import React, { useEffect, useState } from 'react';
import UserService from '../../services/UserService';
import avatar from '../../img/avatar.png';

const UserDetails = () => {

    const [allusers, setAllUsers] = useState([]);
    const [filterusers, setFilterUsers] = useState(allusers);
    const [showMsg, setShowMsg] = useState(false);
    const [status, setStatus] = useState('');
    const [statusMsg, setStatusMsg] = useState('');
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        getAllUsers();
    }, []);

    const getAllUsers = () => {
        UserService.getAllUsers().then(response => {
            if (response.data.statusMessage === 'Successfully Retrieved' && response.status === 200) {
                setAllUsers(response.data.message);
                setFilterUsers(response.data.message);
            }
        }).catch(err => {
            if (err.response.data.statusMessage === 'No Results Found') {
                setShowMsg(true);
                setStatus("Failed");
                setStatusMsg(err.response.data.statusMessage);
            }
            console.log(err);
        });
    }

    const handleSearch = (event) => {
        setSearchTerm(event.target.value.toLowerCase());        
    }

    useEffect(()=>{
        const result = allusers.filter((data) => {
            return (data && data.loginId && data.loginId.toLowerCase().indexOf(searchTerm) > -1 ||
            data && data.firstName  && data.firstName.toLowerCase().indexOf(searchTerm) > -1 ||
            data && data.lastName && data.lastName.toLowerCase().indexOf(searchTerm) > -1)
        })
        setFilterUsers(result);
    },[searchTerm]);

    return (
        <>
            <div className="form-outline">
                <input type="search" id="form1" className="form-control mb-2" placeholder="Search Username" style={{width:"30%", marginLeft:"80px"}} onChange={handleSearch} />
            </div>

        {filterusers.map(userObj => (
            <div className="col-5 mx-1 my-1 px-4" style={{ backgroundColor: "#ffffff", borderRadius: "8px", overflow: "hidden" }}>
                <div className="text-center user-detail">
                    <div className="pt-3 pb-3">
                        <div className="mx-auto">
                            <img src={avatar} alt="User" className="flex-shrink-0 me-2 rounded-circle" style={{ width: 60, height: 60, display: "inline-block", verticalAlign: "top" }} />
                        </div>
                        <div className="pt-2">
                            <h6>{userObj.firstName} {userObj.lastName}</h6>
                            <p className="mb-1" style={{ fontSize: "13px", color: "#1DA1F2", fontWeight: "bolder" }}>{userObj.loginId}<span> | </span><span style={{ color: "black" }}>{userObj.emailId}</span></p>
                            <address>
                                <p className="mb-1" style={{ fontSize: "13px", color: "black" }}><b style={{ color: "black" }}>Contact No : </b>{userObj.contactNumber}</p>
                            </address>
                        </div>
                    </div>
                </div>
            </div>
        ))}
        </>
    );
}

export default UserDetails;
