import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link, useHistory } from 'react-router-dom';
import Modal from '../../responsemessage/Modal';
import UserService from '../../services/UserService';

const LoginComponent = () => {
  const { register, handleSubmit, formState: { errors } } = useForm({});
  const [showMsg, setShowMsg] = useState(false);
  const [status, setStatus] = useState('');
  const [statusMsg, setStatusMsg] = useState('');

  const history = useHistory();
  const formSubmit = (values) => {
    console.log(values);
    const data = {
      loginId: values.username,
      userPassword: values.password
    };

    UserService.loginUser(data).then(response => {
      setStatusMsg(response.data.statusMessage);
      console.log(response);
      if (response.data.loginStatus === 'Login Successful' && response.status === 200) {
        setStatus("Success");
        history.push({
          pathname: '/home',
          state: {
            loginId: data.loginId,
          }
        })
        UserService.saveJWT(data.loginId, response.data.accessToken);
      }
    }).catch(err => {
      setShowMsg(true);
      setStatus("Failed");
      setStatusMsg(err.response.data.statusMessage);
    });
  }

  return (
    <>
      <Modal show={showMsg} title={status} message={statusMsg} onClose={() => setShowMsg(false)} />
      <div className="auth-wrapper pb-3">
        <div className="main-container">
          <div className="login-content">
            <form onSubmit={e => e.preventDefault()}>
              <div className="form-header mb-1">
                <h4>Login</h4>
              </div>
              <div className="form-group mb-1">
                <label>Username</label>
                <input type="text" className="form-control" name="username" placeholder="Enter username" {
                  ...register('username', {
                    required: 'You must specify a Username',
                  })} />
                {errors.username && (<span className="errorMsg">{errors.username.message}</span>)}
              </div>
              <div className="form-group mb-1" style={{ padding: "7px 0px 0px 0px" }}>
                <label>Password</label>
                <input type="password" className="form-control" name="password" placeholder="Enter password" {
                  ...register('password', {
                    required: 'You must specify a password',
                  })} />
                {errors.password && (<span className="errorMsg">{errors.password.message}</span>)}
              </div>
              <div className="form-submit">
                <button type="submit" className="btn btn-primary" style={{ backgroundColor: "#1DA1F2", borderStyle: "none" }} onClick={handleSubmit(formSubmit)}><i className="bi bi-twitter" style={{ paddingRight: "0.30rem" }}></i>Submit</button>
              </div>

              <p className="forgot-password text-right">
                <Link to={"/forgot"}>Forgot password ?</Link>
              </p>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}

export default LoginComponent;
