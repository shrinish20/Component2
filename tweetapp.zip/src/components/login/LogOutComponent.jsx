import React, { Component } from 'react';

class LogOutComponent extends Component {
    render() {
        return (
            <div>
                <h1>You have been logged out </h1>
            </div>
        );
    }
}

export default LogOutComponent;
