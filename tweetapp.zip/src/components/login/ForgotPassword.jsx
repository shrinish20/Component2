import React, { useState } from 'react';
// import { useHistory } from 'react-router';
import Modal from '../../responsemessage/Modal';
import UserService from '../../services/UserService';
import ResetPassword from './ResetPassword';


const ForgotPassword = () => {
    const [username, setUsername] = useState('');
    const [showMsg, setShowMsg] = useState(false);    
    const [status, setStatus] = useState('');
    const [statusMsg, setStatusMsg] = useState('');
    const checkUsername=(event) => {
        event.preventDefault(); 
        console.log(username);
        const user = username;
        UserService.isValidUser(user).then(response => { 
            setStatusMsg(response.data.statusMessage);
            console.log(response);           
            if(response.data.statusMessage === 'Successfully Retrieved' && response.status === 200) {                
                setStatus("Success");
            }            
        }).catch(err => {
            setStatusMsg(err.response.data.statusMessage);
            if(err.response.data.statusMessage === 'User Not Found') {
                setShowMsg(true);                                
                setStatus("Failed");
            }
        });
    }

    return (<>
    {status==="Success" && <ResetPassword user={username}/>}
        <Modal show={showMsg} title={status} message = {statusMsg} onClose={()=>setShowMsg(false)}>
            <p>Username does not exist</p>
        </Modal>
    <div className="auth-wrapper pb-3">
        <div className="main-container">
            <div>
                <form onSubmit={checkUsername}>
                    <div className="form-header mb-1">
                        <h4>Forgot Password ?</h4>
                    </div>
                    <div className="form-group mb-1">
                        <label>Username</label>
                        <input type="text" className="form-control" name="username" onChange={event=>setUsername(event.target.value)} placeholder="Enter your username" />
                    </div>
                    <div className="form-submit">
                        <button type="submit" className="btn btn-primary" style={{ backgroundColor: "#1DA1F2", borderStyle: "none" }} ><i className="bi bi-twitter" style={{ paddingRight: "0.30rem" }}></i>Verify</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </>);
}

export default ForgotPassword;
