import React, { useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import Modal from '../../responsemessage/Modal';
import UserService from '../../services/UserService';
import LoginComponent from './LoginComponent';

const ResetPassword = (props) => {
    const [showMsg, setShowMsg] = useState(false);    
    const [status, setStatus] = useState('');
    const [statusMsg, setStatusMsg] = useState('');
    const { register, handleSubmit, formState: { errors }, watch } = useForm({});
    const password = useRef({});
    password.current = watch("password", "");

    const formSubmit = (values) => {
        let user = props.user;
        const data = {
            loginId: user,
            userPassword: values.password
        };

        UserService.resetPassword(data).then(response => {
            setStatusMsg(response.data.statusMessage);
            console.log(response);
            if (response.data.statusMessage === 'Password Re-setted Successfully' && response.status === 200) {
                setStatus("Success");
                setShowMsg(true);  
            }
        }).catch(err => {
            setStatus("Failed");
            setShowMsg(true);  
            setStatusMsg("Password Re-set UnSuccessful. Please try again later");
        });

    }

    const validatePassword = (value) => {
        if (value.length < 8) {
            return 'Password should be atleast 8 characters.';
        } else if (!/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s)(?=.*[!@#$*])/.test(value)) {
            return 'Password should contain atleast one uppercase letter, lowercase letter, digit and special characters.';
        }
        return true;
    }

    return (<>
        {status==="Success" && <LoginComponent/>}
        <Modal show={showMsg} title={status} message={statusMsg} onClose={() => setShowMsg(false)}/>
        <div className="auth-wrapper pb-3">
            <div className="main-container">
                <div>
                    <form onSubmit={e => e.preventDefault()}>
                        <div className="form-header mb-1">
                            <h4>Reset Password</h4>
                        </div>
                        <div className="form-group mb-1">
                            <label>Password
                        <span className="text-danger"> *</span></label>
                            <input type="password" className="form-control" name="password"{
                                ...register('password', {
                                    required: 'You must specify a password',
                                    validate: validatePassword
                                })} placeholder="Enter password" />
                            {errors.password && (<span className="errorMsg">{errors.password.message}</span>)}
                        </div>
                        <div className="form-group mb-1">
                            <label>Confirm Password
                        <span className="text-danger"> *</span></label>
                            <input type="password" className="form-control" name="confirmpassword" {
                                ...register('confirmpassword', {
                                    validate: value => value === password.current || "Password Mismatch."
                                })} placeholder="Confirm Password" />
                            {errors.confirmpassword && (<span className="errorMsg">{errors.confirmpassword.message}</span>)}
                        </div>
                        <div className="form-submit">
                            <button type="submit" className="btn btn-primary" style={{ backgroundColor: "#1DA1F2", borderStyle: "none" }} onClick={handleSubmit(formSubmit)}><i className="bi bi-key-fill" style={{ paddingRight: "0.31rem" }}></i>Reset</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </>);
}

export default ResetPassword;
