const validatePassword = (value) => {
    if (value.length < 8) {
        return 'Password should be atleast 8 characters.';
    } else if (!/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s)(?=.*[!@#$*])/.test(value)) {
        return 'Password should contain atleast one uppercase letter, lowercase letter, digit and special characters.';
    }
    return true;
}