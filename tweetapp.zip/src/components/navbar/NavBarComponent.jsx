import React from 'react';
import logo from '../../img/twitter.png';
import { Link } from 'react-router-dom';

const NavBarComponent = (props) => {
    const username = localStorage.getItem('authenticatedUser');
    let navbar = '';
    if (props.loggedInUser) {
        navbar = (
            <ul className="navbar-nav">
                <li className="nav-item">
                    <Link className="nav-link"
                        to={"/myTweets"}>MY TWEETS</Link>
                </li>
                <li className="nav-item">
                    <Link className="nav-link" to={"/home"}>ALL TWEETS</Link>
                </li>
                <li className="nav-item">
                    <Link className="nav-link" to={`/${username}/post`}>POST TWEET</Link>
                </li>
                <li className="nav-item">
                    <Link className="nav-link" to={"/users"}>ALL USERS</Link>
                </li>
                <li className="nav-item">
                    <Link className="nav-link" to={"/login"} onClick={() => localStorage.clear()}>LOGOUT</Link>
                </li>
            </ul>
        )
    } else {
        navbar = (
            <ul className="navbar-nav">
                <li className="nav-item">
                    <Link className="nav-link" to={"/login"}>LOGIN</Link>
                </li>
                <li className="nav-item">
                    <Link className="nav-link" to={"/register"}>SIGN UP</Link>
                </li>
            </ul>
        )
    }
    return (
        <nav className="navbar navbar-expand-sm bg-light fixed-top py-0">
            <Link to={"/login"} className="navbar-brand">
                <img id="logo" className="d-inline-block mr-1" src={logo} alt="Tweet App" />
                <span style={{ fontWeight: "600" }}>TWEET APP</span>
            </Link>
            <button className="navbar-toggler mr-1 custom-toggle" type="button" data-bs-toggle="collapse"
                data-target="#navBarToggle" aria-controls="navBarToggle" aria-expanded="false" aria-label="Toggle Navigation">
                <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navBarToggle">
                {navbar}

                {/* <ul className="navbar-nav">
                        <li className="nav-item">
                        <Link className="nav-link" to={"/sign-up"}>POST TWEET</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to={"/sign-in"}>MY TWEETS</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to={"/sign-up"}>ALL TWEETS</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to={"/sign-up"}>ALL USERS</Link>
                        </li>                        
                        <li className="nav-item">
                            <Link className="nav-link" to={"/logout"} onClick={UserService.logout}>LOGOUT</Link>
                        </li>
                    </ul> */}

            </div>
            {/*<Link className="navbar-brand" to={"/sign-in"}>Tweet App</Link>*/}
        </nav>
    );
}

export default NavBarComponent;