import axios from 'axios';
class UserService {

    registerUser(data) {
        return axios.post('register', data);
    }

    loginUser(data) {
        return axios.post('login', data);
    }

    isValidUser(username) {
        console.log(username);
        return axios.get('user/search/' + username);
    }

    getAllUsers() {
        return axios.get('users/all');
    }

    resetPassword(data) {
        return axios.post('resetPassword', data);
    }

    saveJWT(username, token) {
        localStorage.setItem('authenticatedUser', username);
        localStorage.setItem('jwt', token);
        // this.setupAxiosInterceptors(this.createJwtToken(token))
    }

    getLoggedInUserName() {
        let user = localStorage.getItem('authenticateUser')
        if (user === null) return ''
        return user
    }

    // createJwtToken(token) {
    //     return `Bearer ${token}`;
    // }

    // isUserLoggedIn() {
    //     let user = localStorage.getItem('authenticatedUser')
    //     if(user === null) return false
    //     return true
    // }

    logout() {
        localStorage.clear();
    }

    // setupAxiosInterceptors(token) {
    //     axios.interceptors.request.use(
    //         (config) => {
    //             if(this.isUserLoggedIn()) {
    //                 config.headers.authorization = token                
    //             }
    //             return config;
    //         },
    //         (error) => {
    //             return Promise.reject(error);
    //         }
    //     )
    // }
}

export default new UserService()