import axios from 'axios';

class TweetService {
    getAllTweets() {
        return axios.get('all');
    }

    getTweets(username) {
        return axios.get(username);
    }

    postTweet(data) {
        return axios.post(data.loginId + '/add', data);
    }

    likeTweet(username, id, isLiked) {
        return axios.put(username + '/like/' + id, null, { params: { isLiked } });
    }

    replyTweet(username, id, data) {
        return axios.post(username + '/reply/' + id, data);
    }

    updateTweet(username, id, data) {
        return axios.put(username + '/update/' + id, data);
    }

    deleteTweet(username, id) {
        return axios.delete(username + '/delete/' + id);
    }
}

export default new TweetService();