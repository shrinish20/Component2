import React from 'react';

const Modal = (props) => {
    if(!props.show) {
        return null;
    }
    return (
        <div className="model-dialog modal-dialog-centered" onClick={props.onClose}>
            <div className="modal-content" onClick={event=>event.stopPropagation()}>
                <div className="modal-header">
                    <h5 className={`modal-title ${props.title === "Failed"? "text-danger" :"text-success"}`}><i className={`bi bi-exclamation-triangle-fill ${props.title === "Failed"? "text-danger" :"text-success"}`}></i>  {props.title}</h5>
                    <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div className="modal-body">
                    <p style={{fontSize:"medium",fontWeight:"600", color:"#1DA1F2"}}>{props.message}</p>
                </div>
                <div className="modal-footer">
                    {/* <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={props.onClose}>Close</button>                     */}
                    <button type="button" className="btn btn-primary" data-bs-dismiss="modal" onClick={props.onClose} style={{ backgroundColor: "#1DA1F2", borderStyle: "none" }}><i className="bi bi-twitter" style={{ paddingRight: "0.30rem" }}></i>Close</button>
                </div>
            </div>
        </div>
    );
}

export default Modal;
