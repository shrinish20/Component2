package com.tweetapp.util;

import org.springframework.stereotype.Component;

@Component
public class DBInitializer{
	/*
	 * 
	 * private UserRepository userRepo;
	 * 
	 * public DBInitializer(UserRepository userRepo) { this.userRepo = userRepo; }
	 * 
	 * @Autowired private TweetRepository tweetRepo;
	 * 
	 * @Override public void run(String... args) throws Exception {
	 * 
	 * User userA = new User("Lucifer", "Morningstar", "Male", "10-04-1996",
	 * "lucifer@msn.com", "morningstar");
	 * 
	 * User userB = new User("Chandler", "Bing", "Male", "20-08-1966",
	 * "chandler@gmail.com", "bing");
	 * 
	 * User userC = new User("Billy", "Butcher", "Male", "11-02-1985",
	 * "billy@yahoo.com", "butcher");
	 * 
	 * userA.setTweetList(Arrays.asList( new Tweet("lucifer@msn.com", "Hello World",
	 * (new Timestamp(new Date().getTime())).toString(),Arrays.asList()), new
	 * Tweet("lucifer@msn.com", "Hello All", (new Timestamp(new
	 * Date().getTime())).toString(), Arrays.asList()), new Tweet("lucifer@msn.com",
	 * "Hello Everyone", (new Timestamp(new Date().getTime())).toString(),
	 * Arrays.asList()), new Tweet("lucifer@msn.com", "Hello Buddy", (new
	 * Timestamp(new Date().getTime())).toString(), Arrays.asList())));
	 * 
	 * userB.setTweetList(Arrays.asList( new Tweet("chandler@gmail.com",
	 * "Hey World", (new Timestamp(new
	 * Date().getTime())).toString(),Arrays.asList()), new
	 * Tweet("chandler@gmail.com", "Hey All", (new Timestamp(new
	 * Date().getTime())).toString(),Arrays.asList()), new
	 * Tweet("chandler@gmail.com", "Hey Everyone", (new Timestamp(new
	 * Date().getTime())).toString(),Arrays.asList()), new
	 * Tweet("chandler@gmail.com", "Hey Buddy", (new Timestamp(new
	 * Date().getTime())).toString(),Arrays.asList())));
	 * 
	 * userC.setTweetList(Arrays.asList( new Tweet("billy@yahoo.com", "Hi World",
	 * (new Timestamp(new Date().getTime())).toString(),Arrays.asList()), new
	 * Tweet("billy@yahoo.com", "Hi All", (new Timestamp(new
	 * Date().getTime())).toString(),Arrays.asList()), new Tweet("billy@yahoo.com",
	 * "Hi Everyone", (new Timestamp(new
	 * Date().getTime())).toString(),Arrays.asList()), new Tweet("billy@yahoo.com",
	 * "Hi Buddy", (new Timestamp(new
	 * Date().getTime())).toString(),Arrays.asList())));
	 * 
	 * List<Tweet> tweetList = Arrays.asList( new Tweet("lucifer@msn.com",
	 * "Hello World", ((new Timestamp(new
	 * Date().getTime()))).toString(),Arrays.asList()), new Tweet("lucifer@msn.com",
	 * "Hello All", ((new Timestamp(new
	 * Date().getTime()))).toString(),Arrays.asList()), new Tweet("lucifer@msn.com",
	 * "Hello Everyone", ((new Timestamp(new
	 * Date().getTime()))).toString(),Arrays.asList()), new Tweet("lucifer@msn.com",
	 * "Hello Buddy", (new Timestamp(new
	 * Date().getTime())).toString(),Arrays.asList()), new
	 * Tweet("chandler@gmail.com", "Hey World", (new Timestamp(new
	 * Date().getTime())).toString(),Arrays.asList()), new
	 * Tweet("chandler@gmail.com", "Hey All", (new Timestamp(new
	 * Date().getTime())).toString(),Arrays.asList()), new
	 * Tweet("chandler@gmail.com", "Hey Everyone", (new Timestamp(new
	 * Date().getTime())).toString(),Arrays.asList()), new
	 * Tweet("chandler@gmail.com", "Hey Buddy", (new Timestamp(new
	 * Date().getTime())).toString(),Arrays.asList()), new Tweet("billy@yahoo.com",
	 * "Hi World", (new Timestamp(new
	 * Date().getTime())).toString(),Arrays.asList()), new Tweet("billy@yahoo.com",
	 * "Hi All", (new Timestamp(new Date().getTime())).toString(),Arrays.asList()),
	 * new Tweet("billy@yahoo.com", "Hi Everyone", (new Timestamp(new
	 * Date().getTime())).toString(),Arrays.asList()), new Tweet("billy@yahoo.com",
	 * "Hi Buddy", (new Timestamp(new
	 * Date().getTime())).toString(),Arrays.asList()));
	 * 
	 * this.userRepo.deleteAll();
	 * 
	 * List<User> userList = Arrays.asList(userA, userB, userC);
	 * this.userRepo.saveAll(userList); this.tweetRepo.saveAll(tweetList); }
	 * 
	 */}
